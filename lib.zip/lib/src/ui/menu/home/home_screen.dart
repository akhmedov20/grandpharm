import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:grandpharm/src/ui/offers/offers_screen.dart';
import 'package:grandpharm/src/widget/box/box_widget.dart';
import 'package:grandpharm/src/widget/pictures/picture_widget.dart';
import 'package:grandpharm/src/widget/product/product_widget.dart';
import 'package:grandpharm/src/widget/textstyle/textstyle_widget.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}
//   List <dynamic> images = [
//   "assets/images/backgroundsecond.png",
//   "assets/images/teal.png",
//   "assets/images/lovebackground.png",
//   "assets/images/green.png",
//   ];
//    List <dynamic> icons = [
//   "assets/icons/medicine.svg",
//   "assets/icons/location.svg",
//   "assets/icons/kreditcard.svg",
//   "assets/icons/card.svg",
// ];
class _HomeScreenState extends State<HomeScreen> {
  TextEditingController _controller = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 50,),
            Row(
              children: [
                Container(
                  margin: EdgeInsets.only(left: 15),
                  width: 300,
                  height: 52,
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: [
                        BoxShadow(
                            blurRadius: 3
                        )
                      ]
                  ),
                  child: Row(
                    children: [
                      SizedBox(width: 15,),
                      Icon(Icons.search,color: Colors.grey,),
                      SizedBox(width: 10,),
                      Expanded(
                        child: TextField(
                          controller: _controller,
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText: "Dori istash",
                            hintStyle: Appstyle.fourteen(Colors.grey),
                          ),
                        ),
                      ),
                      IconButton(onPressed: (){}, icon: Icon(
                        Icons.keyboard_voice,color: Colors.grey,size: 30,
                      ))
                    ],
                  ),
                ),
                SizedBox(width: 25,),
                IconButton(onPressed: (){}, icon: Icon(
                  Icons.print,color: Colors.blue,size: 30,
                ))
              ],
            ),
            SizedBox(height: 20,),
            SizedBox(width: MediaQuery.of(context).size.width,height: 115,
              child: Expanded(
                child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: 4,
                    itemBuilder: (context,index){
                      return Padding(
                        padding: const EdgeInsets.only(left: 5,right: 5),
                        child: BoxWidget(text: "Ko'rish", image: "assets/images/backgroundsecond.png",
                            icon: "assets/icons/medical.svg", letter: "Aptekada"),
                      );
                    }
                ),
              ),
            ),
            SizedBox(height: 30,),
            SizedBox(width: MediaQuery.of(context).size.width,
              height: 155,
              child: Expanded(
                child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: 5,
                    itemBuilder: (context,index){
                      return Padding(
                        padding:  EdgeInsets.only(left: 8,right: 8),
                        child: PictureWidget(picture: "assets/images/baby.png"),
                      );
                    }
                ),),
            ),
            SizedBox(height: 20,),
            Row(children: [
              SizedBox(width: 15,),
              Text("Eng zo'r takliflar",style: GoogleFonts.aladin(
                textStyle: Appstyle.twenty(Colors.black),
              ),),
              SizedBox(width: 170,),
              TextButton(onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context){
                return OffersScreen();
                }));
              }, child: Text("Hammasi",style: GoogleFonts.aladin(
                textStyle: Appstyle.twenty(Colors.blue),
              ),),)
            ],),
            SizedBox(width: MediaQuery.of(context).size.width,
              height: 265,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  ProductWidget(images: "assets/images/ayflox.png",
                      text: "АЙФЛОКС капли глазные 0,3% 5 мл",
                      letter: "Aseptica, ООО", price: "120 000 сум"),
                  ProductWidget(images: "assets/images/ayflix.png",
                      text: "АЙФЛОКС капли глазные 0,3% 5 мл",
                      letter: "Aseptica, ООО", price: "99 000 сум"),
                  ProductWidget(images: "assets/images/ayinda.png",
                      text: "АЙФЛОКС капли глазные 0,3% 5 мл",
                      letter: "Aseptica, ООО", price: "120 000 сум"),
                  ProductWidget(images: "assets/images/ayflox.png",
                      text: "АЙФЛОКС капли глазные 0,3% 5 мл",
                      letter: "Aseptica, ООО", price: "120 000 сум"),
                ],
              ),
            ),
            SizedBox(height: 20,),
            Row(children: [
              SizedBox(width: 15,),
              Text("Foydali maqolalar",style: GoogleFonts.aladin(
                textStyle: Appstyle.twenty(Colors.black),
              ),),
              SizedBox(width: 170,),
              Text("Hammasi",style: GoogleFonts.aladin(
                textStyle: Appstyle.twenty(Colors.blue),
              ),),
            ],),
            SizedBox(height: 10,),
            SizedBox(width: MediaQuery.of(context).size.width,
              height: 120,
              child: ListView(scrollDirection: Axis.horizontal,
                children: [
                Container(
                  margin: EdgeInsets.only(right: 5,left: 5),
                  width: 298,
                  height: 118,
                  child: Row(children: [
                    Container(
                      width: 98,
                      height: 108,
                      child: ClipRRect(borderRadius: BorderRadius.circular(10),
                          child: Image.asset("assets/images/women.png",fit: BoxFit.cover,)),
                    ),
                    Container(
                      width: 190,
                      height: 108,
                      child: Column(
                        children: [
                          SizedBox(height: 20,),
                          Padding(
                            padding: const EdgeInsets.only(right: 120),
                            child: Text("10 - iyul",style: Appstyle.twelve(Colors.grey),),
                          ),
                          SizedBox(height: 5,),
                          Padding(
                            padding: const EdgeInsets.only(left: 10),
                            child: Text("Недержание у взрослых: как сохранить здоровье",style: Appstyle.fourteen(Colors.black),),
                          )
                        ],
                      ),
                    )
                  ],),
                ),
                  Container(
                    margin: EdgeInsets.only(right: 5,left: 5),
                    width: 298,
                    height: 118,
                    child: Row(children: [
                      Container(
                        width: 98,
                        height: 108,
                        child: ClipRRect(borderRadius: BorderRadius.circular(10),
                            child: Image.asset("assets/images/women.png",fit: BoxFit.cover,)),
                      ),
                      Container(
                        width: 190,
                        height: 108,
                        child: Column(
                          children: [
                            SizedBox(height: 20,),
                            Padding(
                              padding: const EdgeInsets.only(right: 120),
                              child: Text("10 - iyul",style: Appstyle.twelve(Colors.grey),),
                            ),
                            SizedBox(height: 5,),
                            Padding(
                              padding: const EdgeInsets.only(left: 10),
                              child: Text("Недержание у взрослых: как сохранить здоровье",style: Appstyle.fourteen(Colors.black),),
                            )
                          ],
                        ),
                      )
                    ],),
                  ),
                  Container(
                    margin: EdgeInsets.only(right: 5,left: 5),
                    width: 298,
                    height: 118,
                    child: Row(children: [
                      Container(
                        width: 98,
                        height: 108,
                        child: ClipRRect(borderRadius: BorderRadius.circular(10),
                            child: Image.asset("assets/images/women.png",fit: BoxFit.cover,)),
                      ),
                      Container(
                        width: 190,
                        height: 108,
                        child: Column(
                          children: [
                            SizedBox(height: 20,),
                            Padding(
                              padding: const EdgeInsets.only(right: 120),
                              child: Text("10 - iyul",style: Appstyle.twelve(Colors.grey),),
                            ),
                            SizedBox(height: 5,),
                            Padding(
                              padding: const EdgeInsets.only(left: 10),
                              child: Text("Недержание у взрослых: как сохранить здоровье",style: Appstyle.fourteen(Colors.black),),
                            )
                          ],
                        ),
                      )
                    ],),
                  ),
              ],),
            ),
            SizedBox(height: 10,)
          ],
        ),
      )
    );
  }
}
