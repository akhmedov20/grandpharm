import 'package:flutter/material.dart';

import '../color/color_widget.dart';

class Appstyle {


  static TextStyle thirty(color){
    return TextStyle(
        color: color,
        fontSize: 30,
        fontWeight: FontWeight.bold
    );
  }
  static TextStyle twentyfour(color){
    return TextStyle(
        color: color,
        fontSize: 24,
        fontWeight: FontWeight.bold
    );
  }
  static TextStyle twenty(color){
    return TextStyle(
        color: color,
        fontSize: 20,
        fontWeight: FontWeight.bold
    );
  }
  static TextStyle eighteen(color){
    return TextStyle(
        color: color,
        fontSize: 18,
        fontWeight: FontWeight.bold
    );
  }
  static TextStyle sixteen(color){
    return TextStyle(
        color: color,
        fontSize: 16,
        fontWeight: FontWeight.bold
    );
  }
  static TextStyle fourteen(color){
    return TextStyle(
        color: color,
        fontSize: 14,
        fontWeight: FontWeight.bold
    );
  }
  static TextStyle twelve(color){
    return TextStyle(
        color: color,
        fontSize: 12,
        fontWeight: FontWeight.bold
    );
  }
  static TextStyle ten(color){
    return TextStyle(
        color: color,
        fontSize: 10,
        fontWeight: FontWeight.bold
    );
  }

}