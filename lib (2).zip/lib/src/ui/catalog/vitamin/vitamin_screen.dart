import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:grandpharm/src/ui/catalog/for%20men/for_men_screen.dart';
import 'package:grandpharm/src/widget/appbar/appbar_widget.dart';

import '../../../widget/textstyle/textstyle_widget.dart';

class VitaminScreen extends StatefulWidget {
  const VitaminScreen({Key? key}) : super(key: key);

  @override
  State<VitaminScreen> createState() => _VitaminScreenState();
}

class _VitaminScreenState extends State<VitaminScreen> {
  @override
  Widget build(BuildContext context) {
    TextEditingController _controller = TextEditingController();
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          SizedBox(height: 30,),
          AppbarWidget(write: "Витамины и БАДы", writing: ""),
          Row(
            children: [
              Container(
                margin: EdgeInsets.only(left: 15),
                width: 300,
                height: 52,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                          blurRadius: 3
                      )
                    ]
                ),
                child: Row(
                  children: [
                    SizedBox(width: 15,),
                    Icon(Icons.search,color: Colors.grey,),
                    SizedBox(width: 10,),
                    Expanded(
                      child: TextField(
                        controller: _controller,
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: "Dori istash",
                          hintStyle: Appstyle.fourteen(Colors.grey),
                        ),
                      ),
                    ),
                    IconButton(onPressed: (){
                      showModalBottomSheet(
                          isDismissible: true,
                          context: context,
                          builder: (BuildContext context){
                            return Container(
                              width: 375,
                              height: 350,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(15),
                                  color: Colors.white
                              ),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  SizedBox(height: 20,),
                                  Center(child: Text("Ovozli qidiruv",
                                    style: GoogleFonts.roboto(
                                        textStyle: Appstyle.eighteen(Colors.black)
                                    ),),),
                                  SizedBox(height: 10,),
                                  SizedBox(
                                    width: 270,
                                    child: Text("Произнесите название препарата,\nдействующего вещества или симптом",
                                      style: GoogleFonts.roboto(
                                          textStyle: Appstyle.fourteen(Colors.grey)
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: 60,),
                                  SizedBox(width: 58,height: 58,
                                      child: IconButton(onPressed: (){},
                                          icon: SvgPicture.asset("assets/icons/voiceoutline.svg",))),
                                  SizedBox(height: 50,),
                                  Container(
                                    margin: EdgeInsets.symmetric(horizontal: 15),
                                    width: MediaQuery.of(context).size.width,
                                    height: 44,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(15),
                                        border: Border.all(color: Colors.grey)
                                    ),
                                    child: Center(child: Text(
                                      "Bekor qilish",style: GoogleFonts.aladin(
                                        textStyle: Appstyle.eighteen(Colors.blue)
                                    ),
                                    ),),
                                  )
                                ],
                              ),
                            );
                          }
                      );
                    }, icon: Icon(
                      Icons.keyboard_voice,color: Colors.grey,size: 30,
                    ))
                  ],
                ),
              ),
              SizedBox(width: 25,),
              IconButton(onPressed: (){}, icon: Icon(
                Icons.print,color: Colors.blue,size: 30,
              ))
            ],
          ),
          SizedBox(height: 10,),
          GestureDetector(
            onTap: (){},
            child: ListTile(
              title: Text("Monovitaminlar",style: GoogleFonts.roboto(
                textStyle: Appstyle.sixteen(Colors.black)
              ),),
              trailing: Icon(CupertinoIcons.right_chevron,color: Colors.grey,),
            ),
          ),
          GestureDetector(onTap: (){},
            child: ListTile(
              title: Text("Multivitaminlar",style: GoogleFonts.roboto(
                  textStyle: Appstyle.sixteen(Colors.black)
              ),),
              trailing: Icon(CupertinoIcons.right_chevron,color: Colors.grey,),
            ),
          ),
          GestureDetector(onTap: (){},
            child: ListTile(
              title: Text("Xomilador va emizuvchilar uchun",style: GoogleFonts.roboto(
                  textStyle: Appstyle.sixteen(Colors.black)
              ),),
              trailing: Icon(CupertinoIcons.right_chevron,color: Colors.grey,),
            ),
          ),
          GestureDetector(onTap: (){
          Navigator.push(context, MaterialPageRoute(builder: (context){
            return MenScreen();
          }));
          },
            child: ListTile(
              title: Text("Erkaklar uchun",style: GoogleFonts.roboto(
                  textStyle: Appstyle.sixteen(Colors.black)
              ),),
              trailing: Icon(CupertinoIcons.right_chevron,color: Colors.grey,),
            ),
          ),
          GestureDetector(onTap: (){},
            child: ListTile(
              title: Text("Bolalar uchun ",style: GoogleFonts.roboto(
                  textStyle: Appstyle.sixteen(Colors.black)
              ),),
              trailing: Icon(CupertinoIcons.right_chevron,color: Colors.grey,),
            ),
          ),
          GestureDetector(onTap: (){},
            child: ListTile(
              title: Text("Ayollar uchun",style: GoogleFonts.roboto(
                  textStyle: Appstyle.sixteen(Colors.black)
              ),),
              trailing: Icon(CupertinoIcons.right_chevron,color: Colors.grey,),
            ),
          ),
          GestureDetector(onTap: (){},
            child: ListTile(
              title: Text("Saxiri borlar uchun",style: GoogleFonts.roboto(
                  textStyle: Appstyle.sixteen(Colors.black)
              ),),
              trailing: Icon(CupertinoIcons.right_chevron,color: Colors.grey,),
            ),
          ),
        ],
      ),
    );
  }
}
