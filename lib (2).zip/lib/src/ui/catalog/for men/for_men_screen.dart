import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:grandpharm/src/ui/catalog/for%20men/filtr_screen.dart';
import 'package:grandpharm/src/ui/catalog/producter/producter_screen.dart';
import 'package:grandpharm/src/ui/catalog/vitamin/vitamin_screen.dart';
import 'package:page_transition/page_transition.dart';
import '../../../widget/textstyle/textstyle_widget.dart';

class MenScreen extends StatefulWidget {
  const MenScreen({Key? key}) : super(key: key);

  @override
  State<MenScreen> createState() => _MenScreenState();
}

class _MenScreenState extends State<MenScreen> {
  double start = 1000.0;
  double end = 1000000.0;
  int _value = 0;
  TextEditingController _controller = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Column(
        children: [
          SizedBox(height: 30,),
          Container(
            width: MediaQuery.of(context).size.width,
            height: 76,
            child: Row(children: [
              IconButton(
                icon: Icon(CupertinoIcons.left_chevron,color: Colors.blue,),
                onPressed: (){
                  Navigator.pop(context, MaterialPageRoute(builder: (context){
                    return VitaminScreen();
                  }));
                },
              ),
              Container(
                width: 320,
                height: 76,
                child: Column(children: [
                  SizedBox(height: 5,),
                  Text("Erkaklar uchun",style: GoogleFonts.aladin(
                    textStyle: Appstyle.eighteen(Colors.black),
                  ),),
                  Text("14 tovar",style: GoogleFonts.roboto(
                    textStyle: Appstyle.fourteen(Colors.grey),
                  ),),
                ],),
              )
            ],),
          ),
          SizedBox(height: 5,),
          Row(
            children: [
              Container(
                margin: EdgeInsets.only(left: 15),
                width: 300,
                height: 52,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                          blurRadius: 3
                      )
                    ]
                ),
                child: Row(
                  children: [
                    SizedBox(width: 15,),
                    Icon(Icons.search,color: Colors.grey,),
                    SizedBox(width: 10,),
                    Expanded(
                      child: TextField(
                        controller: _controller,
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: "Dori istash",
                          hintStyle: Appstyle.fourteen(Colors.grey),
                        ),
                      ),
                    ),
                    IconButton(onPressed: (){}, icon: Icon(
                      Icons.keyboard_voice,color: Colors.grey,size: 30,
                    ))
                  ],
                ),
              ),
              SizedBox(width: 25,),
              IconButton(onPressed: (){}, icon: Icon(
                Icons.print,color: Colors.blue,size: 30,
              ))
            ],
          ),
          SizedBox(height: 8,),
          Container(
            width: MediaQuery.of(context).size.width,
            height: 49,
            child: Row(children: [
              SizedBox(width: 10,),
              IconButton(onPressed: (){
                showModalBottomSheet(
                    isDismissible: true,
                    context: context,
                    builder: (BuildContext context){
                      return Container(
                        width: 375,
                        height: 350,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(15),
                            color: Colors.white
                        ),
                        child: Column(
                          children: [
                            SizedBox(height: 30,),
                            Container(
                              width: MediaQuery.of(context).size.width,
                              height: 44,
                              child: Row(children: [
                                SizedBox(width: 20,),
                                Text("По названиею (А-Я)",style: GoogleFonts.roboto(
                                    textStyle: Appstyle.sixteen(Colors.black)
                                ),),
                                Spacer(),
                                Radio(
                                    value: 0,
                                    groupValue: _value,
                                    onChanged: (value){
                                      setState(() {
                                        _value = value!;
                                      });
                                    }),
                              ],),
                            ),
                            Container(
                              width: MediaQuery.of(context).size.width,
                              height: 44,
                              child: Row(children: [
                                SizedBox(width: 20,),
                                Text("По названиею (Я-А)",style: GoogleFonts.roboto(
                                    textStyle: Appstyle.sixteen(Colors.black)
                                ),),
                                Spacer(),
                                Radio(
                                    value: 1,
                                    groupValue: _value,
                                    onChanged: (value){
                                      setState(() {
                                        _value = value!;
                                      });
                                    }),
                              ],),
                            ),
                            Container(
                              width: MediaQuery.of(context).size.width,
                              height: 44,
                              child: Row(children: [
                                SizedBox(width: 20,),
                                Text("По цене (по возрастанию)",style: GoogleFonts.roboto(
                                    textStyle: Appstyle.sixteen(Colors.black)
                                ),),
                                Spacer(),
                                Radio(
                                    value: 2,
                                    groupValue: _value,
                                    onChanged: (value){
                                      setState(() {
                                        _value = value!;
                                      });
                                    }),
                              ],),
                            ),
                            Container(
                              width: MediaQuery.of(context).size.width,
                              height: 44,
                              child: Row(children: [
                                SizedBox(width: 20,),
                                Text("По цене (по убыванию)",style: GoogleFonts.roboto(
                                    textStyle: Appstyle.sixteen(Colors.black)
                                ),),
                                Spacer(),
                                Radio(
                                    value: 3,
                                    groupValue: _value,
                                    onChanged: (value){
                                      setState(() {
                                        _value = value!;
                                      });
                                    }),
                              ],),
                            ),
                            Container(
                              width: MediaQuery.of(context).size.width,
                              height: 44,
                              child: Row(children: [
                                SizedBox(width: 20,),
                                Text("По наличию скидки",style: GoogleFonts.roboto(
                                    textStyle: Appstyle.sixteen(Colors.black)
                                ),),
                                Spacer(),
                                Radio(
                                    value: 4,
                                    groupValue: _value,
                                    onChanged: (value){
                                      setState(() {
                                        _value = value!;
                                      });
                                    }),
                              ],),
                            ),
                          ],
                        ),
                      );
                    }
                );
              }, icon: Icon(Icons.line_style,color: Colors.blue,)),
              Text("Nomi bo'yicha",style: GoogleFonts.roboto(
                  textStyle: Appstyle.sixteen(Colors.black)
              ),),
              SizedBox(width: 40,),
              Container(width: 1,
                height: 40,
                color: Colors.grey,
              ),
              SizedBox(width: 60,),
              IconButton(onPressed: (){
                showModalBottomSheet(
                    isDismissible: true,
                    context: context,
                    builder: (BuildContext context){
                      return Container(
                      width: 375,
                      height: MediaQuery.of(context).size.height,
                      decoration: BoxDecoration(
                      borderRadius: BorderRadius.horizontal(
                      right: Radius.circular(15),
                      left: Radius.circular(15),
                      )
                      ),
                      child: Column(children: [
                      SizedBox(height: 8,),
                      Center(child: Text("Filtr",style: GoogleFonts.aladin(
                      textStyle: Appstyle.twenty(Colors.black)
                      ),),),
                      SizedBox(height: 20,),
                      Padding(
                      padding: const EdgeInsets.only(right: 300),
                      child: Text("Narxi",style: Appstyle.fourteen(Colors.grey),),
                      ),
                      RangeSlider(
                      values: RangeValues(start,end),
                      labels: RangeLabels(start.toString(),end.toString()),
                      onChanged: (value){
                      setState(() {
                      start = value.start;
                      end = value.end;
                      });
                      },
                      min: 1000,
                      max: 1000000,
                      ),
                      SizedBox(height: 10,),
                      Row(children: [
                      SizedBox(width: 10,),
                      Container(
                      width: 164,
                      height: 52,
                      decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: [
                      BoxShadow(
                      blurRadius: 3
                      )
                      ]
                      ),
                      child: Column(children: [
                      SizedBox(height: 5,),
                      Padding(
                      padding: const EdgeInsets.only(right: 115),
                      child: Text("Dan",style: Appstyle.twelve(Colors.grey),),
                      ),
                      Row(children: [
                      Padding(
                      padding: const EdgeInsets.only(left: 10),
                      child: Text(start.toStringAsFixed(2),style: Appstyle.fourteen(Colors.black),),
                      ),
                      Spacer(),
                      Padding(
                      padding: const EdgeInsets.only(right: 10),
                      child: Text("so'm",style: Appstyle.sixteen(Colors.grey),),
                      )
                      ],)
                      ],),
                      ),
                      SizedBox(width: 15,),
                      Container(
                      width: 164,
                      height: 52,
                      decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: [
                      BoxShadow(
                      blurRadius: 3
                      )
                      ]
                      ),
                      child: Column(children: [
                      SizedBox(height: 5,),
                      Padding(
                      padding: const EdgeInsets.only(right: 105),
                      child: Text("Gacha",style: Appstyle.twelve(Colors.grey),),
                      ),
                      Row(children: [
                      Padding(
                      padding: const EdgeInsets.only(left: 10),
                      child: Text(end.toStringAsFixed(2),style: Appstyle.fourteen(Colors.black),),
                      ),
                      Spacer(),
                      Padding(
                      padding: const EdgeInsets.only(right: 10),
                      child: Text("so'm",style: Appstyle.sixteen(Colors.grey),),
                      )
                      ],)
                      ],),
                      ),
                      ],),
                      SizedBox(height: 5,),
                      ListTile(
                      title: Text("Forma soni",style: Appstyle.fourteen(Colors.black),),
                      trailing: IconButton(onPressed: (){},icon: Icon(CupertinoIcons.right_chevron,color: Colors.black,),),
                      ),
                      ListTile(
                      title: Text("Ishlab chiqaruvchilar",style: Appstyle.fourteen(Colors.black),),
                      trailing: IconButton(onPressed: (){
                        Navigator.push(context, PageTransition(type: PageTransitionType.fade,child: ProducterScreen()));
                      },icon: Icon(CupertinoIcons.right_chevron,color: Colors.black,),),
                      ),
                      ListTile(
                      title: Text("Mamlakati",style: Appstyle.fourteen(Colors.black),),
                      trailing: IconButton(onPressed: (){},icon: Icon(CupertinoIcons.right_chevron,color: Colors.black,),),
                      ),
                      ListTile(
                      title: Text("Ta'sir qiluvchi modda",style: Appstyle.fourteen(Colors.black),),
                      trailing: IconButton(onPressed: (){},icon: Icon(CupertinoIcons.right_chevron,color: Colors.black,),),
                      ),
                        GestureDetector(onTap: (){
                          Navigator.push(context, PageTransition(type: PageTransitionType.fade,child: FiltrScreen()));
                        },
                          child: Container(margin: EdgeInsets.symmetric(horizontal: 15),
                            width: MediaQuery.of(context).size.width,height: 44,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: Colors.blue[900]
                            ),child: Center(child: Text("Qo'llash",style: Appstyle.sixteen(Colors.white),),),),
                        ),
                      ],),
                      );
                    }
                );
              }, icon: SvgPicture.asset("assets/icons/settings.svg")),
              Text("Filtr",style: GoogleFonts.roboto(
                  textStyle: Appstyle.sixteen(Colors.black)
              ),),
            ],),
          ),
          SizedBox(width: 360,height: 590,
            child: ListView(scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 359,
                  height: 160,
                  child: Row(children: [
                    Container(
                      width: 112,
                      height: 112,
                      child: Image.asset("assets/images/ayinda.png"),
                    ),
                    Container(
                      width: 247,
                      height: 160,
                      child: Column(children: [
                        SizedBox(height: 8,),
                        Text("АЙФЛОКС каплиглазные 0,3%5 мл №30 блистер",style: GoogleFonts.roboto(
                            textStyle: Appstyle.fourteen(Colors.black)
                        ),),
                        SizedBox(height: 8,),
                        Padding(
                          padding: EdgeInsets.only(right: 200),
                          child: Text("Эвалар",style: GoogleFonts.roboto(
                              textStyle: Appstyle.twelve(Colors.grey)
                          ),),
                        ),
                        SizedBox(height: 10,),
                        Row(children: [
                          Padding(
                            padding:  EdgeInsets.only(right: 50),
                            child: Text("39 000 сум",style: GoogleFonts.roboto(
                                textStyle: Appstyle.sixteen(Colors.red[700])
                            ),),
                          ),
                          Padding(
                            padding:  EdgeInsets.only(right: 10),
                            child: Text("59 000 сум",
                              style: GoogleFonts.roboto(
                                textStyle: Appstyle.fourteen(Colors.grey),
                              decoration: TextDecoration.lineThrough
                            ),),
                          ),
                        ],),
                        SizedBox(height: 5,),
                        Row(children: [
                          Container(
                            width: 120,height: 30,
                            decoration: BoxDecoration(
                                color: Colors.blue,
                                borderRadius: BorderRadius.circular(10)
                            ),
                            child: Center(child: Text(
                              "Korzinkaga",style: GoogleFonts.roboto(
                                textStyle: Appstyle.twelve(Colors.white)
                            ),
                            ),),
                          ),
                          SizedBox(width: 70,),
                          IconButton(onPressed: (){}, icon: Icon(Icons.favorite_border))
                        ],)
                      ],),
                    ),
                  ],),
                ),
                Container(
                  width: 359,
                  height: 160,
                  child: Row(children: [
                    Container(
                      width: 112,
                      height: 112,
                      child: Image.asset("assets/images/doritsin.png"),
                    ),
                    Container(
                      width: 247,
                      height: 160,
                      child: Column(children: [
                        SizedBox(height: 8,),
                        Text("Доритрицин таб.д/рассасывания №10",style: GoogleFonts.roboto(
                            textStyle: Appstyle.fourteen(Colors.black)
                        ),),
                        SizedBox(height: 8,),
                        Padding(
                          padding: EdgeInsets.only(right: 200),
                          child: Text("Эвалар",style: GoogleFonts.roboto(
                              textStyle: Appstyle.twelve(Colors.grey)
                          ),),
                        ),
                        SizedBox(height: 10,),
                        Padding(
                          padding:  EdgeInsets.only(right: 160),
                          child: Text("39 000 сум",style: GoogleFonts.roboto(
                              textStyle: Appstyle.sixteen(Colors.black)
                          ),),
                        ),
                        SizedBox(height: 5,),
                        Row(children: [
                          Container(
                            width: 120,height: 30,
                            decoration: BoxDecoration(
                                color: Colors.blue,
                                borderRadius: BorderRadius.circular(10)
                            ),
                            child: Center(child: Text(
                              "Korzinkaga",style: GoogleFonts.roboto(
                                textStyle: Appstyle.twelve(Colors.white)
                            ),
                            ),),
                          ),
                          SizedBox(width: 70,),
                          IconButton(onPressed: (){}, icon: Icon(Icons.favorite_border))
                        ],)
                      ],),
                    ),
                  ],),
                ),
                Container(
                  width: 359,
                  height: 160,
                  child: Row(children: [
                    Container(
                      width: 112,
                      height: 112,
                      child: Image.asset("assets/images/bifiform.png"),
                    ),
                    Container(
                      width: 247,
                      height: 160,
                      child: Column(children: [
                        SizedBox(height: 8,),
                        Padding(
                          padding: const EdgeInsets.only(right: 98),
                          child: Text("Бифиформ капс. №30",style: GoogleFonts.roboto(
                              textStyle: Appstyle.fourteen(Colors.black)
                          ),),
                        ),
                        SizedBox(height: 8,),
                        Padding(
                          padding: EdgeInsets.only(right: 200),
                          child: Text("Эвалар",style: GoogleFonts.roboto(
                              textStyle: Appstyle.twelve(Colors.grey)
                          ),),
                        ),
                        SizedBox(height: 10,),
                        Padding(
                          padding:  EdgeInsets.only(right: 160),
                          child: Text("39 000 сум",style: GoogleFonts.roboto(
                              textStyle: Appstyle.sixteen(Colors.black)
                          ),),
                        ),
                        SizedBox(height: 5,),
                        Row(children: [
                          Container(
                            width: 120,height: 30,
                            decoration: BoxDecoration(
                                color: Colors.blue,
                                borderRadius: BorderRadius.circular(10)
                            ),
                            child: Center(child: Text(
                              "Korzinkaga",style: GoogleFonts.roboto(
                                textStyle: Appstyle.twelve(Colors.white)
                            ),
                            ),),
                          ),
                          SizedBox(width: 70,),
                          IconButton(onPressed: (){}, icon: Icon(Icons.favorite_border))
                        ],)
                      ],),
                    ),
                  ],),
                ),
                Container(
                  width: 359,
                  height: 160,
                  child: Row(children: [
                    Container(
                      width: 112,
                      height: 112,
                      child: Image.asset("assets/images/ayinda.png"),
                    ),
                    Container(
                      width: 247,
                      height: 160,
                      child: Column(children: [
                        SizedBox(height: 8,),
                        Text("АЙФЛОКС каплиглазные 0,3%5 мл №30 блистер",style: GoogleFonts.roboto(
                            textStyle: Appstyle.fourteen(Colors.black)
                        ),),
                        SizedBox(height: 8,),
                        Padding(
                          padding: EdgeInsets.only(right: 200),
                          child: Text("Эвалар",style: GoogleFonts.roboto(
                              textStyle: Appstyle.twelve(Colors.grey)
                          ),),
                        ),
                        SizedBox(height: 10,),
                        Padding(
                          padding:  EdgeInsets.only(right: 160),
                          child: Text("39 000 сум",style: GoogleFonts.roboto(
                              textStyle: Appstyle.sixteen(Colors.black)
                          ),),
                        ),
                        SizedBox(height: 5,),
                        Row(children: [
                          Container(
                            width: 120,height: 30,
                            decoration: BoxDecoration(
                                color: Colors.blue,
                                borderRadius: BorderRadius.circular(10)
                            ),
                            child: Center(child: Text(
                              "Korzinkaga",style: GoogleFonts.roboto(
                                textStyle: Appstyle.twelve(Colors.white)
                            ),
                            ),),
                          ),
                          SizedBox(width: 70,),
                          IconButton(onPressed: (){}, icon: Icon(Icons.favorite_border))
                        ],)
                      ],),
                    ),
                  ],),
                ),
                Container(
                  width: 359,
                  height: 160,
                  child: Row(children: [
                    Container(
                      width: 112,
                      height: 112,
                      child: Image.asset("assets/images/ayinda.png"),
                    ),
                    Container(
                      width: 247,
                      height: 160,
                      child: Column(children: [
                        SizedBox(height: 8,),
                        Text("АЙФЛОКС каплиглазные 0,3%5 мл №30 блистер",style: GoogleFonts.roboto(
                            textStyle: Appstyle.fourteen(Colors.black)
                        ),),
                        SizedBox(height: 8,),
                        Padding(
                          padding: EdgeInsets.only(right: 200),
                          child: Text("Эвалар",style: GoogleFonts.roboto(
                              textStyle: Appstyle.twelve(Colors.grey)
                          ),),
                        ),
                        SizedBox(height: 10,),
                        Padding(
                          padding:  EdgeInsets.only(right: 160),
                          child: Text("39 000 сум",style: GoogleFonts.roboto(
                              textStyle: Appstyle.sixteen(Colors.black)
                          ),),
                        ),
                        SizedBox(height: 5,),
                        Row(children: [
                          Container(
                            width: 120,height: 30,
                            decoration: BoxDecoration(
                                color: Colors.blue,
                                borderRadius: BorderRadius.circular(10)
                            ),
                            child: Center(child: Text(
                              "Korzinkaga",style: GoogleFonts.roboto(
                                textStyle: Appstyle.twelve(Colors.white)
                            ),
                            ),),
                          ),
                          SizedBox(width: 70,),
                          IconButton(onPressed: (){}, icon: Icon(Icons.favorite_border))
                        ],)
                      ],),
                    ),
                  ],),
                ),
              ],),
          )
        ],
      ),
    );
  }
}
