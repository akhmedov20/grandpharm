import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:grandpharm/src/ui/catalog/vitamin/vitamin_screen.dart';

import '../../widget/textstyle/textstyle_widget.dart';

class CatalogScreen extends StatelessWidget {
  const CatalogScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    TextEditingController _controller = TextEditingController();
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 45,),
            Row(
              children: [
                Container(
                  margin: EdgeInsets.only(left: 15),
                  width: 300,
                  height: 52,
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: [
                        BoxShadow(
                            blurRadius: 3
                        )
                      ]
                  ),
                  child: Row(
                    children: [
                      SizedBox(width: 15,),
                      Icon(Icons.search,color: Colors.grey,),
                      SizedBox(width: 10,),
                      Expanded(
                        child: TextField(
                          controller: _controller,
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText: "Dori istash",
                            hintStyle: Appstyle.fourteen(Colors.grey),
                          ),
                        ),
                      ),
                      IconButton(onPressed: (){}, icon: Icon(
                        Icons.keyboard_voice,color: Colors.grey,size: 30,
                      ))
                    ],
                  ),
                ),
                SizedBox(width: 25,),
                IconButton(onPressed: (){}, icon: Icon(
                  Icons.print,color: Colors.blue,size: 30,
                ))
              ],
            ),
            SizedBox(height: 10,),
            GestureDetector(
              onTap: (){},
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: 64,
                child: Row(children: [
                  SizedBox(width: 15,),
                  Image.asset("assets/images/fire.png",),
                  SizedBox(width: 10,),
                  Text("Eng dolzarlari",style: GoogleFonts.roboto(
                      textStyle: Appstyle.sixteen(Colors.black)
                  ),),
                ],),
              ),
            ),
            GestureDetector( onTap: (){},
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: 64,
                child: Row(children: [
                  SizedBox(width: 15,),
                  Image.asset("assets/images/pill.png",),
                  SizedBox(width: 10,),
                  Text("Dorivor preparatlar",style: GoogleFonts.roboto(
                      textStyle: Appstyle.sixteen(Colors.black)
                  ),),
                ],),
              ),
            ),
            GestureDetector( onTap: (){},
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: 64,
                child: Row(children: [
                  SizedBox(width: 15,),
                  Image.asset("assets/images/beauty.png",),
                  SizedBox(width: 10,),
                  Text("Fitopreparatlar",style: GoogleFonts.roboto(
                      textStyle: Appstyle.sixteen(Colors.black)
                  ),),
                ],),
              ),
            ),
            GestureDetector( onTap: (){
              Navigator.push(context, MaterialPageRoute(builder: (context){
                return VitaminScreen();
              }));
            },
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: 64,
                child: Row(children: [
                  SizedBox(width: 15,),
                  Image.asset("assets/images/pharmacy.png",),
                  SizedBox(width: 10,),
                  Text("Vitaminlar va BADlar",style: GoogleFonts.roboto(
                      textStyle: Appstyle.sixteen(Colors.black)
                  ),),
                ],),
              ),
            ),
            GestureDetector( onTap: (){},
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: 64,
                child: Row(children: [
                  SizedBox(width: 15,),
                  Image.asset("assets/images/weddingring.png",),
                  SizedBox(width: 10,),
                  Text("Oila qurish",style: GoogleFonts.roboto(
                      textStyle: Appstyle.sixteen(Colors.black)
                  ),),
                ],),
              ),
            ),
            GestureDetector( onTap: (){},
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: 64,
                child: Row(children: [
                  SizedBox(width: 25,),
                  Image.asset("assets/images/babycarriag.png",),
                  SizedBox(width: 20,),
                  Text("Ona va chaqaloq",style: GoogleFonts.roboto(
                      textStyle: Appstyle.sixteen(Colors.black)
                  ),),
                ],),
              ),
            ),
            GestureDetector( onTap: (){},
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: 64,
                child: Row(children: [
                  SizedBox(width: 15,),
                  Image.asset("assets/images/syringe.png",),
                  SizedBox(width: 10,),
                  Text("Tibbiy mahsulotlar",style: GoogleFonts.roboto(
                      textStyle: Appstyle.sixteen(Colors.black)
                  ),),
                ],),
              ),
            ),
            GestureDetector( onTap: (){},
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: 64,
                child: Row(children: [
                  SizedBox(width: 15,),
                  Image.asset("assets/images/stethoscope.png",),
                  SizedBox(width: 10,),
                  Text("Tibbiy qurilmalar",style: GoogleFonts.roboto(
                      textStyle: Appstyle.sixteen(Colors.black)
                  ),),
                ],),
              ),
            ),
            GestureDetector( onTap: (){},
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: 64,
                child: Row(children: [
                  SizedBox(width: 15,),
                  Image.asset("assets/images/soap.png",),
                  SizedBox(width: 10,),
                  Text("Gigiena, go'zallik va g'amxorlik",style: GoogleFonts.roboto(
                      textStyle: Appstyle.sixteen(Colors.black)
                  ),),
                ],),
              ),
            ),
            GestureDetector( onTap: (){},
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: 64,
                child: Row(children: [
                  SizedBox(width: 15,),
                  Image.asset("assets/images/dumbbell.png",),
                  SizedBox(width: 10,),
                  Text("Sport va fitness",style: GoogleFonts.roboto(
                      textStyle: Appstyle.sixteen(Colors.black)
                  ),),
                ],),
              ),
            ),
            GestureDetector( onTap: (){},
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: 64,
                child: Row(children: [
                  SizedBox(width: 15,),
                  Image.asset("assets/images/glasses.png",),
                  SizedBox(width: 10,),
                  Text("Kontaktni tuzatish",style: GoogleFonts.roboto(
                      textStyle: Appstyle.sixteen(Colors.black)
                  ),),
                ],),
              ),
            ),
          ],
        ),
      )
    );
  }
}
