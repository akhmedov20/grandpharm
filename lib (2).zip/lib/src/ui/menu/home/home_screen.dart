import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:grandpharm/src/ui/articles/articl_screen.dart';
import 'package:grandpharm/src/ui/offers/offers_screen.dart';
import 'package:grandpharm/src/widget/box/box_widget.dart';
import 'package:grandpharm/src/widget/pictures/picture_widget.dart';
import 'package:grandpharm/src/widget/product/product_widget.dart';
import 'package:grandpharm/src/widget/textstyle/textstyle_widget.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  TextEditingController _controller = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 50,),
            Row(
              children: [
                Container(
                  margin: EdgeInsets.only(left: 15),
                  width: 300,
                  height: 52,
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: [
                        BoxShadow(
                            blurRadius: 3
                        )
                      ]
                  ),
                  child: Row(
                    children: [
                      SizedBox(width: 15,),
                      Icon(Icons.search,color: Colors.grey,),
                      SizedBox(width: 10,),
                      Expanded(
                        child: TextField(
                          controller: _controller,
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText: "Dori istash",
                            hintStyle: Appstyle.fourteen(Colors.grey),
                          ),
                        ),
                      ),
                      IconButton(onPressed: (){
                        showModalBottomSheet(
                          isDismissible: true,
                            context: context,
                            builder: (BuildContext context){
                              return Container(
                                width: 375,
                                height: 350,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(15),
                                  color: Colors.white
                                ),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    SizedBox(height: 20,),
                                    Center(child: Text("Ovozli qidiruv",
                                    style: GoogleFonts.roboto(
                                      textStyle: Appstyle.eighteen(Colors.black)
                                    ),),),
                                    SizedBox(height: 10,),
                                    SizedBox(
                                      width: 270,
                                      child: Text("Произнесите название препарата,\nдействующего вещества или симптом",
                                        style: GoogleFonts.roboto(
                                          textStyle: Appstyle.fourteen(Colors.grey)
                                        ),
                                      ),
                                    ),
                                    SizedBox(height: 60,),
                                      SizedBox(width: 58,height: 58,
                                          child: IconButton(onPressed: (){},
                                              icon: SvgPicture.asset("assets/icons/voiceoutline.svg",))),
                                    SizedBox(height: 50,),
                                    Container(
                                      margin: EdgeInsets.symmetric(horizontal: 15),
                                      width: MediaQuery.of(context).size.width,
                                      height: 44,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(15),
                                        border: Border.all(color: Colors.grey)
                                      ),
                                      child: Center(child: Text(
                                        "Bekor qilish",style: GoogleFonts.aladin(
                                        textStyle: Appstyle.eighteen(Colors.blue)
                                      ),
                                      ),),
                                    )
                                  ],
                                ),
                              );
                            }
                        );
                      }, icon: Icon(
                        Icons.keyboard_voice,color: Colors.grey,size: 30,
                      ))
                    ],
                  ),
                ),
                SizedBox(width: 25,),
                IconButton(onPressed: (){}, icon: Icon(
                  Icons.print,color: Colors.blue,size: 30,
                ))
              ],
            ),
            SizedBox(height: 20,),
            SizedBox(width: MediaQuery.of(context).size.width,height: 115,
              child: Expanded(
                child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: 4,
                    itemBuilder: (context,index){
                      return Padding(
                        padding: const EdgeInsets.only(left: 5,right: 5),
                        child: BoxWidget(text: "Ko'rish", image: "assets/images/backgroundsecond.png",
                            icon: "assets/icons/medical.svg", letter: "Aptekada"),
                      );
                    }
                ),
              ),
            ),
            SizedBox(height: 30,),
            SizedBox(width: MediaQuery.of(context).size.width,
              height: 155,
              child: Expanded(
                child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: 5,
                    itemBuilder: (context,index){
                      return Padding(
                        padding:  EdgeInsets.only(left: 8,right: 8),
                        child: PictureWidget(picture: "assets/images/baby.png"),
                      );
                    }
                ),),
            ),
            SizedBox(height: 20,),
            Row(children: [
              SizedBox(width: 15,),
              Text("Eng zo'r takliflar",style: GoogleFonts.aladin(
                textStyle: Appstyle.twenty(Colors.black),
              ),),
              SizedBox(width: 170,),
              TextButton(onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context){
                return OffersScreen();
                }));
              }, child: Text("Hammasi",style: GoogleFonts.aladin(
                textStyle: Appstyle.twenty(Colors.blue),
              ),),)
            ],),
            SizedBox(width: MediaQuery.of(context).size.width,
              height: 265,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  ProductWidget(images: "assets/images/ayflox.png",
                      text: "АЙФЛОКС капли глазные 0,3% 5 мл",
                      letter: "Aseptica, ООО", price: "120 000 сум"),
                  ProductWidget(images: "assets/images/ayflix.png",
                      text: "АЙФЛОКС капли глазные 0,3% 5 мл",
                      letter: "Aseptica, ООО", price: "99 000 сум"),
                  ProductWidget(images: "assets/images/ayinda.png",
                      text: "АЙФЛОКС капли глазные 0,3% 5 мл",
                      letter: "Aseptica, ООО", price: "120 000 сум"),
                  ProductWidget(images: "assets/images/ayflox.png",
                      text: "АЙФЛОКС капли глазные 0,3% 5 мл",
                      letter: "Aseptica, ООО", price: "120 000 сум"),
                ],
              ),
            ),
            SizedBox(height: 20,),
            Row(children: [
              SizedBox(width: 15,),
              Text("Foydali maqolalar",style: GoogleFonts.aladin(
                textStyle: Appstyle.twenty(Colors.black),
              ),),
              SizedBox(width: 165,),
              TextButton(onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context){
                  return ArticlScreen();
                }));
              }, child: Text("Hammasi",style: GoogleFonts.aladin(
                textStyle: Appstyle.twenty(Colors.blue),
              ),),)
            ],),
            SizedBox(height: 10,),
            SizedBox(width: MediaQuery.of(context).size.width,
              height: 120,
              child: ListView(scrollDirection: Axis.horizontal,
                children: [
                Container(
                  margin: EdgeInsets.only(right: 5,left: 5),
                  width: 298,
                  height: 118,
                  child: Row(children: [
                    Container(
                      width: 98,
                      height: 108,
                      child: ClipRRect(borderRadius: BorderRadius.circular(10),
                          child: Image.asset("assets/images/women.png",fit: BoxFit.cover,)),
                    ),
                    Container(
                      width: 190,
                      height: 108,
                      child: Column(
                        children: [
                          SizedBox(height: 20,),
                          Padding(
                            padding: const EdgeInsets.only(right: 120),
                            child: Text("10 - iyul",style: Appstyle.twelve(Colors.grey),),
                          ),
                          SizedBox(height: 5,),
                          Padding(
                            padding: const EdgeInsets.only(left: 10),
                            child: Text("Недержание у взрослых: как сохранить здоровье",style: Appstyle.fourteen(Colors.black),),
                          )
                        ],
                      ),
                    )
                  ],),
                ),
                  Container(
                    margin: EdgeInsets.only(right: 5,left: 5),
                    width: 298,
                    height: 118,
                    child: Row(children: [
                      Container(
                        width: 98,
                        height: 108,
                        child: ClipRRect(borderRadius: BorderRadius.circular(10),
                            child: Image.asset("assets/images/women.png",fit: BoxFit.cover,)),
                      ),
                      Container(
                        width: 190,
                        height: 108,
                        child: Column(
                          children: [
                            SizedBox(height: 20,),
                            Padding(
                              padding: const EdgeInsets.only(right: 120),
                              child: Text("10 - iyul",style: Appstyle.twelve(Colors.grey),),
                            ),
                            SizedBox(height: 5,),
                            Padding(
                              padding: const EdgeInsets.only(left: 10),
                              child: Text("Недержание у взрослых: как сохранить здоровье",style: Appstyle.fourteen(Colors.black),),
                            )
                          ],
                        ),
                      )
                    ],),
                  ),
                  Container(
                    margin: EdgeInsets.only(right: 5,left: 5),
                    width: 298,
                    height: 118,
                    child: Row(children: [
                      Container(
                        width: 98,
                        height: 108,
                        child: ClipRRect(borderRadius: BorderRadius.circular(10),
                            child: Image.asset("assets/images/women.png",fit: BoxFit.cover,)),
                      ),
                      Container(
                        width: 190,
                        height: 108,
                        child: Column(
                          children: [
                            SizedBox(height: 20,),
                            Padding(
                              padding: const EdgeInsets.only(right: 120),
                              child: Text("10 - iyul",style: Appstyle.twelve(Colors.grey),),
                            ),
                            SizedBox(height: 5,),
                            Padding(
                              padding: const EdgeInsets.only(left: 10),
                              child: Text("Недержание у взрослых: как сохранить здоровье",style: Appstyle.fourteen(Colors.black),),
                            )
                          ],
                        ),
                      )
                    ],),
                  ),
              ],),
            ),
            SizedBox(height: 10,)
          ],
        ),
      )
    );
  }
}
