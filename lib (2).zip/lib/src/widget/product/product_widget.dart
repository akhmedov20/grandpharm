import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:grandpharm/src/widget/textstyle/textstyle_widget.dart';

class ProductWidget extends StatelessWidget {
  final String images;
  final String text;
  final String letter;
  final String price;
  const ProductWidget({Key? key, required this.images, required this.text, required this.letter, required this.price}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 140,
      height: 260,
      child: Column(
        children: [
         SizedBox(height: 10,),
          SizedBox(width: 140,height: 140,
              child: Image.asset(images)),
          SizedBox(height: 15,),
          Container(
            width: 140,
            height: 38,
            child: Text(text,textAlign: TextAlign.center,
              style: GoogleFonts.roboto(
              textStyle: Appstyle.fourteen(Colors.black),
            ),),
          ),
          SizedBox(height: 8,),
          Text(letter,style: Appstyle.twelve(Colors.grey),),
          Container(
            width: 120,
            height: 30,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(15),
              color: Colors.blue
            ),
            child: Center(child: Text(price,style: Appstyle.twelve(Colors.white),),),
          )
        ],
      ),
    );
  }
}
