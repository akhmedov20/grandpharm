// import 'dart:html';
//
// import 'package:flutter/material.dart';
// import 'package:grandpharm/src/widget/textstyle/textstyle_widget.dart';
//
// class ButtonWidget extends StatelessWidget {
//   final String text;
//   final double size;
//   final double circle;
//   final double horizontal;
//   final ButtonStyle onTap;
//   const ButtonWidget({Key? key, required this.text, required this.size, required this.circle, required this.horizontal, required this.screen,}) : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     return GestureDetector(
//       onTap: (){
//        onTap;
//       },
//       child: Container(
//         margin: EdgeInsets.symmetric(horizontal: horizontal),
//         width: MediaQuery.of(context).size.width,
//         height: size,
//         decoration: BoxDecoration(
//           color: Colors.blue[900],
//           borderRadius: BorderRadius.circular(circle)
//         ),child: Center(child: Text(text,style: Appstyle.eighteen(Colors.white),)),
//       ),
//     );
//   }
// }
